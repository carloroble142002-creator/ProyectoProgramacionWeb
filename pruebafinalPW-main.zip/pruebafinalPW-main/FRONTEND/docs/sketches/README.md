# ��� Sketches — Avance 01 (TikTok-UL)

Mockups creados en **Balsamiq** que representan las principales pantallas del proyecto.

## Pantallas incluidas
- `login.png`: Pantalla de inicio de sesión / registro.
- `feed.png`: Pantalla principal (inicio) con videos populares y categorías.
- `perfil.png`: Pantalla de perfil del usuario, nivel y monedas.
- Otros: mockups de navegación lateral y menú superior.

## Notas
- Creados por el equipo de TikTok-UL (Mauricio Linares, Leonardo Sotelo, Diego Salazar, Alonso Murillo, Carlos Robles).
- Fecha: Octubre 2025.
- Exportado desde Balsamiq.

    