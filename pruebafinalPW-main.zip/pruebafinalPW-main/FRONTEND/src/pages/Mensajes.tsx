export default function Mensajes() {
  return (
    <div>
      <h2>💬 Mensajes Directos</h2>
      <p>Esta sección mostrará chats entre usuarios (futuro backend).</p>
    </div>
  );
}
