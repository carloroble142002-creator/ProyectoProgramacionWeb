export default function Perfil() {
  return (
    <div>
      <h2>👤 Mi Perfil</h2>
      <p>Pantalla en desarrollo.</p>
    </div>
  );
}
