export const MOCK_STREAMERS = {
  'dance_master': { id: 'dance_master', name: '@dance_master', followers: 125345, profilePic: 'https://i.pravatar.cc/50?u=dance_master' },
  'proGamer': { id: 'proGamer', name: '@proGamer', followers: 892100, profilePic: 'https://i.pravatar.cc/50?u=gamer' },
  'djBeats': { id: 'djBeats', name: '@djBeats', followers: 450230, profilePic: 'https://i.pravatar.cc/50?u=dj' },
  'viajeroUrbano': { id: 'viajeroUrbano', name: '@viajeroUrbano', followers: 230112, profilePic: 'https://i.pravatar.cc/50?u=viajero' },
  'fanFutbol': { id: 'fanFutbol', name: '@fanFutbol', followers: 1200560, profilePic: 'https://i.pravatar.cc/50?u=futbol' },
  'narrador': { id: 'narrador', name: '@narrador', followers: 78000, profilePic: 'https://i.pravatar.cc/50?u=podcast' },
  'arteDigital': { id: 'arteDigital', name: '@arteDigital', followers: 15000, profilePic: 'https://i.pravatar.cc/50?u=arte' },
};