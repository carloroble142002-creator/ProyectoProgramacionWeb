export default function HeaderUser() {
  return null;
}